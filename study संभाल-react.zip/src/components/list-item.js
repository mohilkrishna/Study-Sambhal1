import React from 'react'

import './list-item.css'

const ListItem = (props) => {
  return <div className="list-item-container"></div>
}

export default ListItem
